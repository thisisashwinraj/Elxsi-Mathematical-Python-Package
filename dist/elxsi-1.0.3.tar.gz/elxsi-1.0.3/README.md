#Elxsi

Elxsi is a python package for advanced mathematical operations, distributions and visualizations distributed under the GNU General Public license.